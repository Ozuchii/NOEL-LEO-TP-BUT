const User = require('../repositories/userRepositories');

const createUser = async (req, res) => {
  try {
    const { nom, prenom, adresse, email } = req.body;

    const newUser = await User.createUser({
      nom,
      prenom,
      adresse,
      email,
    });

    res.status(201).json(savedUser);
    } catch (error) {
        console.error("Erreur lors de la création de l'utilisateur :", error);
        res.status(500).json({ error: "Erreur lors de la création de l'utilisateur"});
    }
};

module.exports = {createUser};