const express = require("express");
const router = express.Router();
//const { findUser } = require ("../controllers/users");
const { insertUser } = require ("../controllers/userControllers");

//router.get("/find", findUser);
router.post("/create", createUser);

module.exports = router;