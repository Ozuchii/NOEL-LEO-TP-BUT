const express = require('express')
const app = express()
const router = express.Router
const userRoutes = require('./userRoutes');
const itemRoutes = require('./itemRoutes');

app.use(express.json());

app.use('/user', userRoutes);
app.use('/item', itemRoutes);

module.exports = app