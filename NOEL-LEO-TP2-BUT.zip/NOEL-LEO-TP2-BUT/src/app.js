const express = require('express')
const app = express()
const port = 3000
const { connectTodB } = require('./services/db/connexion')
const { findOne, find, insertOne, insertMany, updateOne, updateMany, replace, deleteOne, deleteMany } = require('./services/db/crud')


app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
  connectTodB();
})

app.get('/findone', async (req, res) => {
  const users = await findOne('users', {}); 
  res.json(users);
});

app.get('/find', async (req, res) => {
  const users = await find('users', {}); 
  res.json(users);
});

app.get('/insertone', async (req, res) => {
  const users = await insertOne('users', {name: 'test'}); 
  res.json(users);
});

app.get('/insertmany', async (req, res) => {
  const users = await insertMany('users', [{name: 'test'}, {name: 'test2'}]); 
  res.json(users);
});

app.get('/updateone', async (req, res) => {
  const users = await updateOne('users', {name: 'test'}, {$set: {name: 'test2'}}); 
  res.json(users);
});

app.get('/updatemany', async (req, res) => {
  const users = await updateMany('users', {name: 'test'}, {$set: {name: 'test2'}}); 
  res.json(users);
});

app.get('/replace', async (req, res) => {
  const users = await replace('users', {name: 'test'}, {name: 'test2'}); 
  res.json(users);
});

app.get('/deleteone', async (req, res) => {
  const users = await deleteOne('users', {name: 'test'}); 
  res.json(users);
});

app.get('/deletemany', async (req, res) => {
  const users = await deleteMany('users', {name: 'test'}); 
  res.json(users);
});
