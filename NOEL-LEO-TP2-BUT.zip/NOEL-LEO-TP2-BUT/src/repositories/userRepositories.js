const db = require('../services/db/connexion');

const createUser = async (userData) => {
  const usersCollection = db.getCollection('user');
  const result = await usersCollection.insertOne(userData);
  return result;
};

const getUserById = async (userId) => {
  const usersCollection = db.getCollection('user');
  const user = await usersCollection.findOne({ _id: userId });
  return user;
};


module.exports = { createUser, getUserById };